"""
app/auth_helpers.py
Session management, login decorators, and helper utilities
"""

from functools import wraps
from flask import session, redirect, url_for, flash, request


def login_required(f):
    """Decorator: redirect to login if not authenticated."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login', next=request.path))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    """Decorator: allow only admin role."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        if session.get('role') != 'admin':
            flash('Access denied. Admin privileges required.', 'danger')
            return redirect(url_for('employee.dashboard'))
        return f(*args, **kwargs)
    return decorated


def employee_required(f):
    """Decorator: allow only employee role (and admin)."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


def compute_payroll(employee, attendance_records):
    """
    Compute payroll from attendance records.
    Returns a dict with all pay components.
    """
    rate_type = employee['rate_type']
    salary_rate = employee['salary_rate']

    total_hours = sum(r['hours_worked'] for r in attendance_records)
    days_worked = len([r for r in attendance_records if r['hours_worked'] > 0])
    total_late_minutes = sum(r['late_minutes'] for r in attendance_records)
    total_overtime_hours = sum(r['overtime_hours'] for r in attendance_records)

    # ── Gross Pay ──────────────────────────────────────────────────────────────
    if rate_type == 'hourly':
        gross_pay = total_hours * salary_rate
    else:  # daily
        gross_pay = days_worked * salary_rate

    # ── Overtime Pay (25% premium) ────────────────────────────────────────────
    if rate_type == 'hourly':
        overtime_pay = total_overtime_hours * salary_rate * 1.25
    else:
        hourly_rate = salary_rate / 8
        overtime_pay = total_overtime_hours * hourly_rate * 1.25

    # ── Late Deduction (per-minute rate) ──────────────────────────────────────
    if rate_type == 'hourly':
        per_min_rate = salary_rate / 60
    else:
        per_min_rate = salary_rate / (8 * 60)
    late_deduction = total_late_minutes * per_min_rate

    gross_with_ot = gross_pay + overtime_pay

    # ── Government Contributions (PH statutory) ───────────────────────────────
    # SSS: simplified bracket (employee share ~4.5%)
    sss = min(gross_with_ot * 0.045, 1125)

    # PhilHealth: 5% split equally (employee pays 2.5%), cap at 5000/month
    philhealth = min(gross_with_ot * 0.025, 2500)

    # Pag-IBIG: 2% up to 5000 salary, max ₱100
    pagibig = min(gross_with_ot * 0.02, 100)

    # ── Withholding Tax (simplified bracket) ──────────────────────────────────
    taxable = gross_with_ot - sss - philhealth - pagibig
    # Semi-monthly equivalent thresholds
    if taxable <= 10417:
        tax = 0
    elif taxable <= 16667:
        tax = (taxable - 10417) * 0.15
    elif taxable <= 33333:
        tax = 937.50 + (taxable - 16667) * 0.20
    elif taxable <= 83333:
        tax = 4270.83 + (taxable - 33333) * 0.25
    elif taxable <= 333333:
        tax = 16770.83 + (taxable - 83333) * 0.30
    else:
        tax = 91770.83 + (taxable - 333333) * 0.35

    total_deductions = late_deduction + sss + philhealth + pagibig + tax
    net_pay = gross_with_ot - total_deductions

    return {
        'days_worked': days_worked,
        'total_hours': round(total_hours, 2),
        'gross_pay': round(gross_pay, 2),
        'overtime_pay': round(overtime_pay, 2),
        'late_deduction': round(late_deduction, 2),
        'sss_deduction': round(sss, 2),
        'philhealth_deduction': round(philhealth, 2),
        'pagibig_deduction': round(pagibig, 2),
        'tax_deduction': round(tax, 2),
        'other_deductions': 0,
        'total_deductions': round(total_deductions, 2),
        'net_pay': round(net_pay, 2),
    }
