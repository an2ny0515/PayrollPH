"""
app/database.py
SQLite3 database setup, schema creation, and sample data seeding
"""

import sqlite3
from werkzeug.security import generate_password_hash
from flask import g


def get_db(app=None):
    """Get database connection from Flask g object or create new."""
    if 'db' not in g:
        from flask import current_app
        db_path = (app or current_app).config['DATABASE']
        g.db = sqlite3.connect(db_path, detect_types=sqlite3.PARSE_DECLTYPES)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db(app):
    """Create all tables if they don't exist."""
    db_path = app.config['DATABASE']
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")
    cursor = conn.cursor()

    # Users table — handles authentication
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'employee',  -- 'admin' or 'employee'
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Employees table — profile linked to a user
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            employee_code TEXT UNIQUE NOT NULL,
            full_name TEXT NOT NULL,
            position TEXT NOT NULL,
            department TEXT DEFAULT 'General',
            rate_type TEXT NOT NULL DEFAULT 'daily',  -- 'daily' or 'hourly'
            salary_rate REAL NOT NULL DEFAULT 0,
            sss_no TEXT,
            pagibig_no TEXT,
            philhealth_no TEXT,
            tin_no TEXT,
            status TEXT DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    ''')

    # Attendance / Time tracking table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            date TEXT NOT NULL,                -- YYYY-MM-DD
            time_in DATETIME,
            time_out DATETIME,
            lat_in REAL,                       -- GPS latitude at time-in
            lng_in REAL,                       -- GPS longitude at time-in
            lat_out REAL,                      -- GPS latitude at time-out
            lng_out REAL,                      -- GPS longitude at time-out
            hours_worked REAL DEFAULT 0,
            is_late INTEGER DEFAULT 0,         -- 1 if arrived after cutoff
            late_minutes INTEGER DEFAULT 0,
            overtime_hours REAL DEFAULT 0,
            remarks TEXT,
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        )
    ''')

    # Payroll table — computed pay periods
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS payroll (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            period_start TEXT NOT NULL,        -- YYYY-MM-DD
            period_end TEXT NOT NULL,          -- YYYY-MM-DD
            days_worked REAL DEFAULT 0,
            total_hours REAL DEFAULT 0,
            gross_pay REAL DEFAULT 0,
            late_deduction REAL DEFAULT 0,
            overtime_pay REAL DEFAULT 0,
            sss_deduction REAL DEFAULT 0,
            pagibig_deduction REAL DEFAULT 0,
            philhealth_deduction REAL DEFAULT 0,
            tax_deduction REAL DEFAULT 0,
            other_deductions REAL DEFAULT 0,
            total_deductions REAL DEFAULT 0,
            net_pay REAL DEFAULT 0,
            status TEXT DEFAULT 'draft',       -- 'draft', 'approved', 'released'
            generated_by INTEGER,              -- admin user_id
            generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            remarks TEXT,
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        )
    ''')

    conn.commit()
    conn.close()
    app.teardown_appcontext(close_db)


def seed_sample_data(app):
    """Insert sample admin and employees if DB is empty."""
    db_path = app.config['DATABASE']
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")
    cursor = conn.cursor()

    # Check if already seeded
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] > 0:
        conn.close()
        return

    # ── Sample Users ──────────────────────────────────────────────────────────
    users = [
        ('admin', generate_password_hash('admin123'), 'admin'),
        ('jdcruz', generate_password_hash('emp123'), 'employee'),
        ('mrsantos', generate_password_hash('emp123'), 'employee'),
        ('alreyes', generate_password_hash('emp123'), 'employee'),
        ('bnlim', generate_password_hash('emp123'), 'employee'),
    ]
    cursor.executemany(
        "INSERT INTO users (username, password, role) VALUES (?, ?, ?)", users
    )
    conn.commit()

    # ── Sample Employees ──────────────────────────────────────────────────────
    employees = [
        # (user_id, employee_code, full_name, position, department, rate_type, salary_rate)
        (2, 'EMP-001', 'Juan dela Cruz', 'Software Engineer', 'IT', 'daily', 1200.00),
        (3, 'EMP-002', 'Maria Santos', 'HR Specialist', 'Human Resources', 'daily', 950.00),
        (4, 'EMP-003', 'Alberto Reyes', 'Accountant', 'Finance', 'daily', 1100.00),
        (5, 'EMP-004', 'Bella Lim', 'Sales Associate', 'Sales', 'hourly', 120.00),
    ]
    cursor.executemany(
        """INSERT INTO employees
           (user_id, employee_code, full_name, position, department, rate_type, salary_rate)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        employees
    )
    conn.commit()

    # ── Sample Attendance (last 14 days) ──────────────────────────────────────
    from datetime import date, timedelta, datetime
    import random

    today = date.today()
    for emp_id in range(1, 5):
        for days_back in range(14, 0, -1):
            d = today - timedelta(days=days_back)
            if d.weekday() >= 5:   # skip weekends
                continue
            # Randomize time-in between 7:50 and 9:00
            ti_hour = 8
            ti_min = random.randint(-10, 60)
            if ti_min < 0:
                ti_hour = 7
                ti_min += 60
            time_in = datetime(d.year, d.month, d.day, ti_hour, ti_min)
            # Time-out between 17:00 and 18:30
            to_hour = 17
            to_min = random.randint(0, 90)
            if to_min >= 60:
                to_hour = 18
                to_min -= 60
            time_out = datetime(d.year, d.month, d.day, to_hour, to_min)
            hours_worked = (time_out - time_in).seconds / 3600

            # Late logic: regular start is 08:00, cap at 480 min (8h)
            is_late = 1 if (ti_hour > 8 or (ti_hour == 8 and ti_min > 0)) else 0
            if is_late:
                diff = (ti_hour - 8) * 60 + ti_min
                late_minutes = diff if diff <= 480 else 0
                if diff > 480:
                    is_late = 0  # night shift, not late
            else:
                late_minutes = 0
            overtime_hours = max(0, hours_worked - 8)

            cursor.execute('''
                INSERT INTO attendance
                (employee_id, date, time_in, time_out,
                 lat_in, lng_in, lat_out, lng_out,
                 hours_worked, is_late, late_minutes, overtime_hours)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                emp_id, d.isoformat(),
                time_in.strftime('%Y-%m-%d %H:%M:%S'),
                time_out.strftime('%Y-%m-%d %H:%M:%S'),
                14.5995 + random.uniform(-0.01, 0.01),   # Manila area lat
                120.9842 + random.uniform(-0.01, 0.01),  # Manila area lng
                14.5995 + random.uniform(-0.01, 0.01),
                120.9842 + random.uniform(-0.01, 0.01),
                round(hours_worked, 2), is_late, late_minutes,
                round(overtime_hours, 2)
            ))

    conn.commit()
    conn.close()
