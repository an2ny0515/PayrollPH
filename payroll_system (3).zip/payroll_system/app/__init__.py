"""
app/__init__.py
Flask application factory with blueprint registration
"""

from flask import Flask
from .database import init_db, seed_sample_data
import os


def create_app():
    app = Flask(__name__, instance_relative_config=True)

    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'payrollph-secret-key-2024')
    app.config['DATABASE'] = os.path.join(app.instance_path, 'payroll.db')

    # Ensure instance folder exists
    os.makedirs(app.instance_path, exist_ok=True)

    # Initialize database
    with app.app_context():
        init_db(app)
        seed_sample_data(app)

    # Register blueprints
    from .blueprints.auth import auth_bp
    from .blueprints.admin import admin_bp
    from .blueprints.employee import employee_bp
    from .blueprints.api import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(employee_bp, url_prefix='/employee')
    app.register_blueprint(api_bp, url_prefix='/api')

    return app
