"""
app/blueprints/employee.py
Employee blueprint: dashboard, time in/out, payslip viewer
"""

from flask import Blueprint, render_template, redirect, url_for, flash, session, request
from ..database import get_db
from ..auth_helpers import login_required
from datetime import date

employee_bp = Blueprint('employee', __name__)


@employee_bp.route('/dashboard')
@login_required
def dashboard():
    db = get_db()
    emp_id = session.get('employee_id')

    if not emp_id:
        flash('Employee profile not found.', 'danger')
        return redirect(url_for('auth.logout'))

    employee = db.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    today = date.today().isoformat()

    # Today's attendance record
    today_record = db.execute(
        "SELECT * FROM attendance WHERE employee_id=? AND date=?",
        (emp_id, today)
    ).fetchone()

    # Recent attendance (last 10 records)
    recent = db.execute('''
        SELECT * FROM attendance WHERE employee_id=?
        ORDER BY date DESC LIMIT 10
    ''', (emp_id,)).fetchall()

    # Recent payslips
    payslips = db.execute('''
        SELECT * FROM payroll WHERE employee_id=? AND status='released'
        ORDER BY period_end DESC LIMIT 5
    ''', (emp_id,)).fetchall()

    return render_template('employee/dashboard.html',
        employee=employee,
        today_record=today_record,
        recent_attendance=recent,
        payslips=payslips,
        today=today
    )


@employee_bp.route('/attendance')
@login_required
def attendance():
    db = get_db()
    emp_id = session.get('employee_id')
    month = request.args.get('month', date.today().strftime('%Y-%m'))

    records = db.execute('''
        SELECT * FROM attendance
        WHERE employee_id=? AND strftime('%Y-%m', date)=?
        ORDER BY date DESC
    ''', (emp_id, month)).fetchall()

    return render_template('employee/attendance.html',
        records=records, month=month)


@employee_bp.route('/payslips')
@login_required
def payslips():
    db = get_db()
    emp_id = session.get('employee_id')

    payslips = db.execute('''
        SELECT * FROM payroll WHERE employee_id=? AND status='released'
        ORDER BY period_end DESC
    ''', (emp_id,)).fetchall()

    return render_template('employee/payslips.html', payslips=payslips)


@employee_bp.route('/payslip/<int:payroll_id>')
@login_required
def view_payslip(payroll_id):
    db = get_db()
    emp_id = session.get('employee_id')

    payslip = db.execute('''
        SELECT p.*, e.full_name, e.employee_code, e.position, e.department,
               e.rate_type, e.salary_rate, e.sss_no, e.pagibig_no,
               e.philhealth_no, e.tin_no
        FROM payroll p
        JOIN employees e ON p.employee_id = e.id
        WHERE p.id=? AND p.employee_id=? AND p.status='released'
    ''', (payroll_id, emp_id)).fetchone()

    if not payslip:
        flash('Payslip not found or not yet released.', 'warning')
        return redirect(url_for('employee.payslips'))

    return render_template('employee/payslip.html', payslip=payslip)
