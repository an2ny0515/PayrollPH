"""
app/blueprints/admin.py
Admin blueprint: employee CRUD, payroll generation, reports
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash
from ..database import get_db
from ..auth_helpers import admin_required, compute_payroll
from datetime import date, timedelta

admin_bp = Blueprint('admin', __name__)


@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    db = get_db()
    total_employees = db.execute(
        "SELECT COUNT(*) FROM employees WHERE status='active'"
    ).fetchone()[0]

    today = date.today().isoformat()
    present_today = db.execute(
        "SELECT COUNT(*) FROM attendance WHERE date=? AND time_in IS NOT NULL",
        (today,)
    ).fetchone()[0]

    # Total payroll released this month
    first_of_month = date.today().replace(day=1).isoformat()
    total_payroll = db.execute(
        "SELECT COALESCE(SUM(net_pay),0) FROM payroll WHERE period_start >= ? AND status='released'",
        (first_of_month,)
    ).fetchone()[0]

    # Recent attendance (last 7 days)
    week_ago = (date.today() - timedelta(days=7)).isoformat()
    recent_attendance = db.execute('''
        SELECT a.*, e.full_name, e.position
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        WHERE a.date >= ?
        ORDER BY a.date DESC, a.time_in DESC
        LIMIT 20
    ''', (week_ago,)).fetchall()

    employees = db.execute(
        "SELECT * FROM employees WHERE status='active' ORDER BY full_name"
    ).fetchall()

    return render_template('admin/dashboard.html',
        total_employees=total_employees,
        present_today=present_today,
        total_payroll=total_payroll,
        recent_attendance=recent_attendance,
        employees=employees,
        today=today
    )


# ── Employee Management ────────────────────────────────────────────────────────

@admin_bp.route('/employees')
@admin_required
def employees():
    db = get_db()
    emps = db.execute('''
        SELECT e.*, u.username, u.role
        FROM employees e
        JOIN users u ON e.user_id = u.id
        ORDER BY e.full_name
    ''').fetchall()
    return render_template('admin/employees.html', employees=emps)


@admin_bp.route('/employees/add', methods=['GET', 'POST'])
@admin_required
def add_employee():
    if request.method == 'POST':
        f = request.form
        db = get_db()
        try:
            # Create user account first
            hashed_pw = generate_password_hash(f['password'])
            db.execute(
                "INSERT INTO users (username, password, role) VALUES (?, ?, 'employee')",
                (f['username'], hashed_pw)
            )
            user_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

            # Create employee profile
            db.execute('''
                INSERT INTO employees
                (user_id, employee_code, full_name, position, department,
                 rate_type, salary_rate, sss_no, pagibig_no, philhealth_no, tin_no)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                user_id, f['employee_code'], f['full_name'], f['position'],
                f.get('department', 'General'), f['rate_type'],
                float(f['salary_rate']),
                f.get('sss_no', ''), f.get('pagibig_no', ''),
                f.get('philhealth_no', ''), f.get('tin_no', '')
            ))
            db.commit()
            flash(f"Employee {f['full_name']} added successfully! ✅", 'success')
            return redirect(url_for('admin.employees'))
        except Exception as e:
            db.rollback()
            flash(f"Error adding employee: {str(e)}", 'danger')

    return render_template('admin/employee_form.html', employee=None, action='add')


@admin_bp.route('/employees/edit/<int:emp_id>', methods=['GET', 'POST'])
@admin_required
def edit_employee(emp_id):
    db = get_db()
    emp = db.execute('''
        SELECT e.*, u.username FROM employees e
        JOIN users u ON e.user_id = u.id WHERE e.id = ?
    ''', (emp_id,)).fetchone()

    if not emp:
        flash('Employee not found.', 'danger')
        return redirect(url_for('admin.employees'))

    if request.method == 'POST':
        f = request.form
        try:
            db.execute('''
                UPDATE employees SET full_name=?, position=?, department=?,
                rate_type=?, salary_rate=?, sss_no=?, pagibig_no=?,
                philhealth_no=?, tin_no=?, status=?
                WHERE id=?
            ''', (
                f['full_name'], f['position'], f.get('department', 'General'),
                f['rate_type'], float(f['salary_rate']),
                f.get('sss_no', ''), f.get('pagibig_no', ''),
                f.get('philhealth_no', ''), f.get('tin_no', ''),
                f.get('status', 'active'), emp_id
            ))
            # Update password if provided
            if f.get('password'):
                db.execute(
                    "UPDATE users SET password=? WHERE id=?",
                    (generate_password_hash(f['password']), emp['user_id'])
                )
            db.commit()
            flash(f"Employee updated successfully! ✅", 'success')
            return redirect(url_for('admin.employees'))
        except Exception as e:
            db.rollback()
            flash(f"Error updating employee: {str(e)}", 'danger')

    return render_template('admin/employee_form.html', employee=emp, action='edit')


@admin_bp.route('/employees/delete/<int:emp_id>', methods=['POST'])
@admin_required
def delete_employee(emp_id):
    db = get_db()
    emp = db.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    if emp:
        db.execute("DELETE FROM users WHERE id=?", (emp['user_id'],))
        db.commit()
        flash('Employee removed successfully.', 'success')
    else:
        flash('Employee not found.', 'danger')
    return redirect(url_for('admin.employees'))


# ── Attendance ─────────────────────────────────────────────────────────────────

@admin_bp.route('/attendance')
@admin_required
def attendance():
    db = get_db()
    date_filter = request.args.get('date', date.today().isoformat())
    emp_filter = request.args.get('employee_id', '')

    query = '''
        SELECT a.*, e.full_name, e.employee_code, e.position
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        WHERE a.date = ?
    '''
    params = [date_filter]

    if emp_filter:
        query += " AND a.employee_id = ?"
        params.append(emp_filter)

    query += " ORDER BY a.time_in DESC"
    records = db.execute(query, params).fetchall()
    employees = db.execute(
        "SELECT id, full_name FROM employees WHERE status='active' ORDER BY full_name"
    ).fetchall()

    return render_template('admin/attendance.html',
        records=records, employees=employees,
        date_filter=date_filter, emp_filter=emp_filter
    )


# ── Payroll ────────────────────────────────────────────────────────────────────

@admin_bp.route('/payroll')
@admin_required
def payroll():
    db = get_db()
    payrolls = db.execute('''
        SELECT p.*, e.full_name, e.employee_code, e.position
        FROM payroll p
        JOIN employees e ON p.employee_id = e.id
        ORDER BY p.generated_at DESC
    ''').fetchall()
    employees = db.execute(
        "SELECT id, full_name FROM employees WHERE status='active' ORDER BY full_name"
    ).fetchall()
    return render_template('admin/payroll.html', payrolls=payrolls, employees=employees)


@admin_bp.route('/payroll/generate', methods=['POST'])
@admin_required
def generate_payroll():
    f = request.form
    period_start = f['period_start']
    period_end = f['period_end']
    emp_ids = f.getlist('employee_ids')  # empty = all employees

    db = get_db()
    if not emp_ids:
        rows = db.execute(
            "SELECT id FROM employees WHERE status='active'"
        ).fetchall()
        emp_ids = [r['id'] for r in rows]

    generated = 0
    for emp_id in emp_ids:
        employee = db.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
        if not employee:
            continue

        attendance_records = db.execute('''
            SELECT * FROM attendance
            WHERE employee_id=? AND date BETWEEN ? AND ?
            AND time_in IS NOT NULL AND time_out IS NOT NULL
        ''', (emp_id, period_start, period_end)).fetchall()

        pay = compute_payroll(employee, attendance_records)

        # Check if payroll already exists for this period
        existing = db.execute('''
            SELECT id FROM payroll
            WHERE employee_id=? AND period_start=? AND period_end=?
        ''', (emp_id, period_start, period_end)).fetchone()

        if existing:
            db.execute('''
                UPDATE payroll SET days_worked=?, total_hours=?, gross_pay=?,
                late_deduction=?, overtime_pay=?, sss_deduction=?,
                pagibig_deduction=?, philhealth_deduction=?, tax_deduction=?,
                total_deductions=?, net_pay=?, generated_by=?, status='draft'
                WHERE id=?
            ''', (pay['days_worked'], pay['total_hours'], pay['gross_pay'],
                  pay['late_deduction'], pay['overtime_pay'], pay['sss_deduction'],
                  pay['pagibig_deduction'], pay['philhealth_deduction'],
                  pay['tax_deduction'], pay['total_deductions'], pay['net_pay'],
                  session['user_id'], existing['id']))
        else:
            db.execute('''
                INSERT INTO payroll
                (employee_id, period_start, period_end, days_worked, total_hours,
                 gross_pay, late_deduction, overtime_pay, sss_deduction,
                 pagibig_deduction, philhealth_deduction, tax_deduction,
                 total_deductions, net_pay, generated_by, status)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'draft')
            ''', (emp_id, period_start, period_end, pay['days_worked'],
                  pay['total_hours'], pay['gross_pay'], pay['late_deduction'],
                  pay['overtime_pay'], pay['sss_deduction'], pay['pagibig_deduction'],
                  pay['philhealth_deduction'], pay['tax_deduction'],
                  pay['total_deductions'], pay['net_pay'], session['user_id']))
        generated += 1

    db.commit()
    flash(f"Payroll generated for {generated} employee(s) ✅", 'success')
    return redirect(url_for('admin.payroll'))


@admin_bp.route('/payroll/<int:payroll_id>/approve', methods=['POST'])
@admin_required
def approve_payroll(payroll_id):
    db = get_db()
    db.execute("UPDATE payroll SET status='released' WHERE id=?", (payroll_id,))
    db.commit()
    flash('Payroll approved and released! ✅', 'success')
    return redirect(url_for('admin.payroll'))


@admin_bp.route('/payroll/<int:payroll_id>/payslip')
@admin_required
def view_payslip_admin(payroll_id):
    db = get_db()
    payslip = db.execute('''
        SELECT p.*, e.full_name, e.employee_code, e.position, e.department,
               e.rate_type, e.salary_rate, e.sss_no, e.pagibig_no,
               e.philhealth_no, e.tin_no
        FROM payroll p
        JOIN employees e ON p.employee_id = e.id
        WHERE p.id = ?
    ''', (payroll_id,)).fetchone()

    if not payslip:
        flash('Payslip not found.', 'danger')
        return redirect(url_for('admin.payroll'))

    return render_template('admin/payslip.html', payslip=payslip)


# ── Map View ───────────────────────────────────────────────────────────────────

@admin_bp.route('/map')
@admin_required
def map_view():
    db = get_db()
    date_filter = request.args.get('date', date.today().isoformat())
    locations = db.execute('''
        SELECT a.lat_in, a.lng_in, a.lat_out, a.lng_out,
               a.time_in, a.time_out, a.date,
               e.full_name, e.position, e.employee_code
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        WHERE a.date = ? AND a.lat_in IS NOT NULL
    ''', (date_filter,)).fetchall()

    return render_template('admin/map.html', locations=[dict(r) for r in locations], date_filter=date_filter)
