"""
app/blueprints/api.py
REST API endpoints for time tracking, GPS logging, payroll actions
"""

from flask import Blueprint, request, jsonify, session
from ..database import get_db
from ..auth_helpers import login_required
from datetime import date, datetime

api_bp = Blueprint('api', __name__)


def api_login_required(f):
    """API-specific login check — returns JSON errors instead of redirects."""
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'success': False, 'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated


def api_admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'success': False, 'error': 'Authentication required'}), 401
        if session.get('role') != 'admin':
            return jsonify({'success': False, 'error': 'Admin access required'}), 403
        return f(*args, **kwargs)
    return decorated


# ── Time Tracking ──────────────────────────────────────────────────────────────

@api_bp.route('/time-in', methods=['POST'])
@api_login_required
def time_in():
    """
    POST /api/time-in
    Body: { lat: float, lng: float }
    Records employee check-in with GPS coordinates.
    """
    emp_id = session.get('employee_id')
    if not emp_id:
        return jsonify({'success': False, 'error': 'No employee profile linked'}), 400

    data = request.get_json() or {}
    lat = data.get('lat')
    lng = data.get('lng')

    today = date.today().isoformat()
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    db = get_db()

    # Check if already timed in today
    existing = db.execute(
        "SELECT * FROM attendance WHERE employee_id=? AND date=?",
        (emp_id, today)
    ).fetchone()

    if existing:
        if existing['time_in']:
            return jsonify({
                'success': False,
                'error': 'Already timed in today',
                'time_in': existing['time_in']
            }), 400
        # Update existing record
        db.execute(
            "UPDATE attendance SET time_in=?, lat_in=?, lng_in=? WHERE id=?",
            (now, lat, lng, existing['id'])
        )
    else:
        # Determine if late (cutoff: 08:00 AM same calendar day)
        current_time = datetime.now()
        cutoff = current_time.replace(hour=8, minute=0, second=0, microsecond=0)
        # Only mark late if time-in is after cutoff AND it's a reasonable work hour
        # (i.e. not someone logging in during night shift after midnight)
        is_late = 0
        late_minutes = 0
        if current_time > cutoff:
            diff_minutes = int((current_time - cutoff).total_seconds() / 60)
            # Cap at 480 minutes (8 hours) — beyond that it's likely a night shift
            if diff_minutes <= 480:
                is_late = 1
                late_minutes = diff_minutes

        db.execute('''
            INSERT INTO attendance
            (employee_id, date, time_in, lat_in, lng_in, is_late, late_minutes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (emp_id, today, now, lat, lng, is_late, late_minutes))

    db.commit()

    return jsonify({
        'success': True,
        'message': 'Time-in recorded successfully! ✅',
        'time_in': now,
        'location': {'lat': lat, 'lng': lng}
    })


@api_bp.route('/time-out', methods=['POST'])
@api_login_required
def time_out():
    """
    POST /api/time-out
    Body: { lat: float, lng: float }
    Records employee check-out, computes hours worked and overtime.
    """
    emp_id = session.get('employee_id')
    if not emp_id:
        return jsonify({'success': False, 'error': 'No employee profile linked'}), 400

    data = request.get_json() or {}
    lat = data.get('lat')
    lng = data.get('lng')

    today = date.today().isoformat()
    now = datetime.now()
    now_str = now.strftime('%Y-%m-%d %H:%M:%S')

    db = get_db()
    record = db.execute(
        "SELECT * FROM attendance WHERE employee_id=? AND date=?",
        (emp_id, today)
    ).fetchone()

    if not record or not record['time_in']:
        return jsonify({'success': False, 'error': 'No time-in record found for today'}), 400

    if record['time_out']:
        return jsonify({
            'success': False,
            'error': 'Already timed out today',
            'time_out': record['time_out']
        }), 400

    # Compute hours worked
    time_in_dt = datetime.strptime(record['time_in'], '%Y-%m-%d %H:%M:%S')
    hours_worked = (now - time_in_dt).seconds / 3600
    overtime_hours = max(0, hours_worked - 8)

    db.execute('''
        UPDATE attendance
        SET time_out=?, lat_out=?, lng_out=?,
            hours_worked=?, overtime_hours=?
        WHERE id=?
    ''', (now_str, lat, lng, round(hours_worked, 2), round(overtime_hours, 2), record['id']))
    db.commit()

    return jsonify({
        'success': True,
        'message': 'Time-out recorded successfully! 👋',
        'time_out': now_str,
        'hours_worked': round(hours_worked, 2),
        'overtime_hours': round(overtime_hours, 2),
        'location': {'lat': lat, 'lng': lng}
    })


@api_bp.route('/attendance/today', methods=['GET'])
@api_login_required
def today_attendance():
    """GET /api/attendance/today — returns today's record for current employee."""
    emp_id = session.get('employee_id')
    today = date.today().isoformat()
    db = get_db()
    record = db.execute(
        "SELECT * FROM attendance WHERE employee_id=? AND date=?",
        (emp_id, today)
    ).fetchone()

    if record:
        return jsonify({'success': True, 'record': dict(record)})
    return jsonify({'success': True, 'record': None})


@api_bp.route('/attendance/locations', methods=['GET'])
@api_admin_required
def attendance_locations():
    """GET /api/attendance/locations?date=YYYY-MM-DD — for map view."""
    date_filter = request.args.get('date', date.today().isoformat())
    db = get_db()
    records = db.execute('''
        SELECT a.lat_in, a.lng_in, a.lat_out, a.lng_out,
               a.time_in, a.time_out,
               e.full_name, e.employee_code, e.position
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        WHERE a.date=? AND a.lat_in IS NOT NULL
    ''', (date_filter,)).fetchall()

    return jsonify({
        'success': True,
        'date': date_filter,
        'locations': [dict(r) for r in records]
    })


@api_bp.route('/employees', methods=['GET'])
@api_admin_required
def get_employees():
    """GET /api/employees — list all active employees."""
    db = get_db()
    employees = db.execute(
        "SELECT id, employee_code, full_name, position, department, rate_type, salary_rate, status FROM employees"
    ).fetchall()
    return jsonify({'success': True, 'employees': [dict(e) for e in employees]})


@api_bp.route('/payroll/generate', methods=['POST'])
@api_admin_required
def api_generate_payroll():
    """POST /api/payroll/generate — programmatic payroll trigger."""
    from ..auth_helpers import compute_payroll
    data = request.get_json() or {}
    period_start = data.get('period_start')
    period_end = data.get('period_end')

    if not period_start or not period_end:
        return jsonify({'success': False, 'error': 'period_start and period_end required'}), 400

    db = get_db()
    employees = db.execute("SELECT * FROM employees WHERE status='active'").fetchall()
    results = []

    for emp in employees:
        records = db.execute('''
            SELECT * FROM attendance
            WHERE employee_id=? AND date BETWEEN ? AND ?
            AND time_in IS NOT NULL AND time_out IS NOT NULL
        ''', (emp['id'], period_start, period_end)).fetchall()

        pay = compute_payroll(emp, records)
        results.append({
            'employee_id': emp['id'],
            'full_name': emp['full_name'],
            **pay
        })

    return jsonify({'success': True, 'results': results, 'count': len(results)})
